# Fictional Status Page

This tiny repository is used for a beginner git history challenge.
